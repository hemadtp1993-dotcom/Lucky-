import React from 'react';
import { ViewState, LocationCoords } from '../types';
import { motion } from 'motion/react';
import { ArrowRight, MapPin, Calendar, Star } from 'lucide-react';

interface HomeViewProps {
  setView: (view: ViewState) => void;
  setGenderPreference: (pref: 'male' | 'female' | 'all') => void;
}

export const HomeView: React.FC<HomeViewProps> = ({ setView, setGenderPreference }) => {
  return (
    <div className="min-h-screen bg-black pt-20">
      {/* Hero Section */}
      <div className="relative h-[80vh] flex items-center">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1521590832167-7bfc17484d20?auto=format&fit=crop&q=80&w=2000" 
            alt="Barber Shop Interior" 
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent" />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-2xl"
          >
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-white mb-6 uppercase leading-tight">
              Book Your <span className="text-amber-500 font-serif italic lowercase text-6xl md:text-8xl pr-2">grooming</span><br/>
              Anytime,<br/>
              Anywhere.
            </h1>
            <p className="text-lg md:text-xl text-zinc-400 mb-10 max-w-lg font-light">
              Experience premium grooming with top-rated salons in your area. Secure your spot instantly.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                onClick={() => {
                  setGenderPreference('male');
                  setView('nearby_shops');
                }}
                className="flex items-center justify-center px-8 py-4 text-sm font-bold tracking-widest text-black uppercase bg-amber-500 hover:bg-amber-400 transition-all rounded-sm group"
              >
                Male (Saloon)
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button 
                onClick={() => {
                  setGenderPreference('female');
                  setView('nearby_shops');
                }}
                className="flex items-center justify-center px-8 py-4 text-sm font-bold tracking-widest text-white uppercase bg-zinc-800 hover:bg-zinc-700 border border-white/10 transition-all rounded-sm group"
              >
                Female (Beauty Parlor)
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-24 bg-zinc-950 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              { icon: MapPin, title: 'Find Nearby', desc: 'Discover the best-rated barber shops right in your neighborhood.' },
              { icon: Calendar, title: 'Easy Booking', desc: 'Select your preferred time slot and service in just a few clicks.' },
              { icon: Star, title: 'Premium Service', desc: 'Enjoy top-tier grooming experiences from vetted professionals.' },
            ].map((feature, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2 }}
                className="flex flex-col items-start"
              >
                <div className="p-4 bg-zinc-900 border border-white/5 rounded-sm mb-6">
                  <feature.icon className="w-8 h-8 text-amber-500" />
                </div>
                <h3 className="text-xl font-medium text-white mb-3 tracking-wide">{feature.title}</h3>
                <p className="text-zinc-500 leading-relaxed font-light">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
