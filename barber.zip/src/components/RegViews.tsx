import React from 'react';
import { ViewState } from '../types';
import { motion } from 'motion/react';
import { ArrowLeft } from 'lucide-react';

interface RegViewsProps {
  setView: (view: ViewState) => void;
  setUser: (user: any) => void;
}

export const CustomerRegView: React.FC<RegViewsProps> = ({ setView, setUser }) => {
  const [gender, setGender] = React.useState<'male' | 'female'>('male');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setUser({ id: 'c1', name: 'John Doe', email: 'john@example.com', role: 'customer' });
    setView('nearby_shops');
  };

  return (
    <div className="min-h-screen bg-black pt-20 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-xl bg-zinc-950 border border-white/10 p-8 rounded-sm shadow-2xl"
      >
        <button 
          onClick={() => setView('role_select')}
          className="flex items-center text-zinc-500 hover:text-white mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </button>

        <h2 className="text-3xl font-bold tracking-widest text-white uppercase mb-8">Customer Details</h2>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold tracking-widest text-zinc-500 uppercase mb-2">Full Name</label>
              <input type="text" required className="w-full bg-zinc-900 border border-white/10 rounded-sm px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition-colors" placeholder="John Doe" />
            </div>
            <div>
              <label className="block text-xs font-bold tracking-widest text-zinc-500 uppercase mb-2">Gender</label>
              <div className="flex bg-zinc-900 p-1 rounded-sm border border-white/10">
                <button 
                  type="button"
                  onClick={() => setGender('male')}
                  className={`flex-1 py-2.5 text-sm font-bold tracking-widest uppercase rounded-sm transition-colors ${gender === 'male' ? 'bg-amber-500 text-black' : 'text-zinc-500 hover:text-white'}`}
                >
                  Male
                </button>
                <button 
                  type="button"
                  onClick={() => setGender('female')}
                  className={`flex-1 py-2.5 text-sm font-bold tracking-widest uppercase rounded-sm transition-colors ${gender === 'female' ? 'bg-amber-500 text-black' : 'text-zinc-500 hover:text-white'}`}
                >
                  Female
                </button>
              </div>
            </div>
            <div>
              <label className="block text-xs font-bold tracking-widest text-zinc-500 uppercase mb-2">Phone Number</label>
              <input type="tel" required className="w-full bg-zinc-900 border border-white/10 rounded-sm px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition-colors" placeholder="+1 (555) 000-0000" />
            </div>
            <div>
              <label className="block text-xs font-bold tracking-widest text-zinc-500 uppercase mb-2">Email</label>
              <input type="email" required className="w-full bg-zinc-900 border border-white/10 rounded-sm px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition-colors" placeholder="john@example.com" />
            </div>
            <div>
              <label className="block text-xs font-bold tracking-widest text-zinc-500 uppercase mb-2">Current Location</label>
              <input type="text" required className="w-full bg-zinc-900 border border-white/10 rounded-sm px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition-colors" placeholder="City, Neighborhood" />
            </div>
          </div>

          <button 
            type="submit"
            className="w-full flex items-center justify-center px-4 py-4 bg-amber-500 text-black rounded-sm hover:bg-amber-400 transition-colors font-bold tracking-widest uppercase text-sm mt-8"
          >
            Submit & Continue
          </button>
        </form>
      </motion.div>
    </div>
  );
};

export const ShopkeeperRegView: React.FC<RegViewsProps> = ({ setView, setUser }) => {
  const [category, setCategory] = React.useState<'unisex' | 'male' | 'female'>('male');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setUser({ id: 's1', name: 'Master Barber', email: 'shop@example.com', role: 'shopkeeper' });
    setView('shopkeeper_dashboard');
  };

  return (
    <div className="min-h-screen bg-black pt-20 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-2xl bg-zinc-950 border border-white/10 p-8 rounded-sm shadow-2xl my-8"
      >
        <button 
          onClick={() => setView('role_select')}
          className="flex items-center text-zinc-500 hover:text-white mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </button>

        <h2 className="text-3xl font-bold tracking-widest text-white uppercase mb-8">Register Shop</h2>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs font-bold tracking-widest text-zinc-500 uppercase mb-2">Owner Name</label>
              <input type="text" required className="w-full bg-zinc-900 border border-white/10 rounded-sm px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition-colors" />
            </div>
            <div>
              <label className="block text-xs font-bold tracking-widest text-zinc-500 uppercase mb-2">Shop Name</label>
              <input type="text" required className="w-full bg-zinc-900 border border-white/10 rounded-sm px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition-colors" />
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs font-bold tracking-widest text-zinc-500 uppercase mb-2">Shop Category (Target Gender)</label>
              <div className="flex bg-zinc-900 p-1 rounded-sm border border-white/10">
                <button 
                  type="button"
                  onClick={() => setCategory('male')}
                  className={`flex-1 py-2.5 text-sm font-bold tracking-widest uppercase rounded-sm transition-colors ${category === 'male' ? 'bg-amber-500 text-black' : 'text-zinc-500 hover:text-white'}`}
                >
                  Male Only
                </button>
                <button 
                  type="button"
                  onClick={() => setCategory('female')}
                  className={`flex-1 py-2.5 text-sm font-bold tracking-widest uppercase rounded-sm transition-colors ${category === 'female' ? 'bg-amber-500 text-black' : 'text-zinc-500 hover:text-white'}`}
                >
                  Female Only
                </button>
                <button 
                  type="button"
                  onClick={() => setCategory('unisex')}
                  className={`flex-1 py-2.5 text-sm font-bold tracking-widest uppercase rounded-sm transition-colors ${category === 'unisex' ? 'bg-amber-500 text-black' : 'text-zinc-500 hover:text-white'}`}
                >
                  Unisex
                </button>
              </div>
            </div>
            <div>
              <label className="block text-xs font-bold tracking-widest text-zinc-500 uppercase mb-2">Phone Number</label>
              <input type="tel" required className="w-full bg-zinc-900 border border-white/10 rounded-sm px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition-colors" />
            </div>
            <div>
              <label className="block text-xs font-bold tracking-widest text-zinc-500 uppercase mb-2">Email</label>
              <input type="email" required className="w-full bg-zinc-900 border border-white/10 rounded-sm px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition-colors" />
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs font-bold tracking-widest text-zinc-500 uppercase mb-2">Shop Address</label>
              <input type="text" required className="w-full bg-zinc-900 border border-white/10 rounded-sm px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition-colors" />
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs font-bold tracking-widest text-zinc-500 uppercase mb-2">Shop Location (Map URL or Coordinates)</label>
              <input type="text" className="w-full bg-zinc-900 border border-white/10 rounded-sm px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition-colors" />
            </div>
            <div>
              <label className="block text-xs font-bold tracking-widest text-zinc-500 uppercase mb-2">Opening Time</label>
              <input type="time" required className="w-full bg-zinc-900 border border-white/10 rounded-sm px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition-colors [color-scheme:dark]" />
            </div>
            <div>
              <label className="block text-xs font-bold tracking-widest text-zinc-500 uppercase mb-2">Closing Time</label>
              <input type="time" required className="w-full bg-zinc-900 border border-white/10 rounded-sm px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition-colors [color-scheme:dark]" />
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs font-bold tracking-widest text-zinc-500 uppercase mb-2">Upload Shop Image</label>
              <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-white/10 border-dashed rounded-sm hover:border-amber-500 transition-colors cursor-pointer bg-zinc-900">
                <div className="space-y-1 text-center">
                  <svg className="mx-auto h-12 w-12 text-zinc-500" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                    <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  <div className="flex text-sm text-zinc-400 justify-center">
                    <span className="relative cursor-pointer rounded-md font-medium text-amber-500 hover:text-amber-400">
                      <span>Upload a file</span>
                    </span>
                    <p className="pl-1">or drag and drop</p>
                  </div>
                  <p className="text-xs text-zinc-500">PNG, JPG up to 5MB</p>
                </div>
              </div>
            </div>
          </div>

          <button 
            type="submit"
            className="w-full flex items-center justify-center px-4 py-4 bg-amber-500 text-black rounded-sm hover:bg-amber-400 transition-colors font-bold tracking-widest uppercase text-sm mt-8"
          >
            Register Shop
          </button>
        </form>
      </motion.div>
    </div>
  );
};
