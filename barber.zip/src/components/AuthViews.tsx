import React from 'react';
import { ViewState } from '../types';
import { motion } from 'motion/react';
import { Mail, ArrowLeft } from 'lucide-react';

import { signInWithGoogle } from '../lib/firebase';

interface AuthViewsProps {
  setView: (view: ViewState) => void;
  setUser: (user: any) => void;
}

export const LoginView: React.FC<AuthViewsProps> = ({ setView, setUser }) => {
  const [role, setRole] = React.useState<'customer' | 'shopkeeper'>('customer');
  const [error, setError] = React.useState<string | null>(null);
  const [isLoading, setIsLoading] = React.useState(false);

  const handleGoogleLogin = async () => {
    try {
      setError(null);
      setIsLoading(true);
      // Store intended role before login so onAuthStateChanged can pick it up
      localStorage.setItem('user_role', role);
      await signInWithGoogle();
      // Navigation is handled by App.tsx's onAuthStateChanged
    } catch (err: any) {
      setError(err.message || 'Failed to sign in with Google');
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black pt-20 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md w-full bg-zinc-950 border border-white/10 p-8 rounded-sm shadow-2xl"
      >
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold tracking-widest text-white uppercase mb-2">Welcome Back</h2>
          <p className="text-zinc-500 font-light">Log in to continue your grooming journey.</p>
        </div>

        <div className="flex bg-zinc-900 p-1 rounded-sm mb-8">
          <button 
            onClick={() => setRole('customer')}
            className={`flex-1 py-2 text-sm font-bold tracking-widest uppercase rounded-sm transition-colors ${role === 'customer' ? 'bg-amber-500 text-black' : 'text-zinc-500 hover:text-white'}`}
          >
            Customer
          </button>
          <button 
            onClick={() => setRole('shopkeeper')}
            className={`flex-1 py-2 text-sm font-bold tracking-widest uppercase rounded-sm transition-colors ${role === 'shopkeeper' ? 'bg-amber-500 text-black' : 'text-zinc-500 hover:text-white'}`}
          >
            Shopkeeper
          </button>
        </div>

        <div className="space-y-4">
          {error && (
            <div className="p-3 mb-4 text-sm text-red-500 bg-red-500/10 border border-red-500/20 rounded-sm">
              {error}
            </div>
          )}
          <button 
            onClick={handleGoogleLogin}
            disabled={isLoading}
            className="w-full flex items-center justify-center px-4 py-3 border border-white/20 text-white rounded-sm hover:bg-white/5 transition-colors group disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <span className="font-medium tracking-wide">Signing in...</span>
            ) : (
              <>
                <svg className="w-5 h-5 mr-3" viewBox="0 0 24 24">
                  <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                  <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                </svg>
                <span className="font-medium tracking-wide">Continue with Google</span>
              </>
            )}
          </button>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-white/10"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-zinc-950 text-zinc-500">Or</span>
            </div>
          </div>

          <button 
            onClick={() => setView('email_login')}
            className="w-full flex items-center justify-center px-4 py-3 bg-amber-500 text-black rounded-sm hover:bg-amber-400 transition-colors"
          >
            <Mail className="w-5 h-5 mr-3" />
            <span className="font-bold tracking-widest uppercase text-sm">Login with Email</span>
          </button>
        </div>

        <div className="mt-8 pt-6 border-t border-white/10 text-center">
          <p className="text-zinc-500 text-sm">
            Don't have an account?{' '}
            <button 
              onClick={() => setView('role_select')}
              className="text-amber-500 hover:text-amber-400 font-bold tracking-wider uppercase transition-colors"
            >
              Register Here
            </button>
          </p>
        </div>
      </motion.div>
    </div>
  );
};

export const EmailLoginView: React.FC<AuthViewsProps> = ({ setView, setUser }) => {
  const [role, setRole] = React.useState<'customer' | 'shopkeeper'>('customer');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock login based on selected role
    if (role === 'customer') {
      setUser({ id: 'c1', name: 'John Doe', email: 'john@example.com', role: 'customer' });
      setView('customer_dashboard');
    } else {
      setUser({ id: 's1', name: 'Master Barber', email: 'shop@example.com', role: 'shopkeeper' });
      setView('shopkeeper_dashboard');
    }
  };

  return (
    <div className="min-h-screen bg-black pt-20 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-zinc-950 border border-white/10 p-8 rounded-sm shadow-2xl"
      >
        <button 
          onClick={() => setView('login')}
          className="flex items-center text-zinc-500 hover:text-white mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </button>

        <h2 className="text-3xl font-bold tracking-widest text-white uppercase mb-8">Log In</h2>

        <form onSubmit={handleLogin} className="space-y-6">
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold tracking-widest text-zinc-500 uppercase mb-2">Login As</label>
              <div className="flex bg-zinc-900 p-1 rounded-sm border border-white/10">
                <button 
                  type="button"
                  onClick={() => setRole('customer')}
                  className={`flex-1 py-2.5 text-sm font-bold tracking-widest uppercase rounded-sm transition-colors ${role === 'customer' ? 'bg-amber-500 text-black' : 'text-zinc-500 hover:text-white'}`}
                >
                  Customer
                </button>
                <button 
                  type="button"
                  onClick={() => setRole('shopkeeper')}
                  className={`flex-1 py-2.5 text-sm font-bold tracking-widest uppercase rounded-sm transition-colors ${role === 'shopkeeper' ? 'bg-amber-500 text-black' : 'text-zinc-500 hover:text-white'}`}
                >
                  Shopkeeper
                </button>
              </div>
            </div>
            <div>
              <label className="block text-xs font-bold tracking-widest text-zinc-500 uppercase mb-2">Email</label>
              <input type="email" required className="w-full bg-zinc-900 border border-white/10 rounded-sm px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition-colors" placeholder="your@email.com" />
            </div>
            <div>
              <label className="block text-xs font-bold tracking-widest text-zinc-500 uppercase mb-2">Password</label>
              <input type="password" required className="w-full bg-zinc-900 border border-white/10 rounded-sm px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition-colors" placeholder="••••••••" />
            </div>
          </div>

          <button 
            type="submit"
            className="w-full flex items-center justify-center px-4 py-4 bg-amber-500 text-black rounded-sm hover:bg-amber-400 transition-colors font-bold tracking-widest uppercase text-sm mt-8"
          >
            Sign In
          </button>
        </form>
      </motion.div>
    </div>
  );
};

export const RoleSelectView: React.FC<AuthViewsProps> = ({ setView }) => {
  return (
    <div className="min-h-screen bg-black pt-20 flex flex-col items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-4xl"
      >
        <button 
          onClick={() => setView('login')}
          className="flex items-center text-zinc-500 hover:text-white mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Login
        </button>

        <h2 className="text-3xl font-bold tracking-widest text-white uppercase mb-10 text-center">Select Your Path</h2>

        <div className="grid md:grid-cols-2 gap-6">
          <div 
            onClick={() => setView('customer_reg')}
            className="group cursor-pointer bg-zinc-950 border border-white/10 p-10 rounded-sm hover:border-amber-500 transition-all text-center relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-amber-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="relative z-10">
              <div className="w-20 h-20 mx-auto bg-zinc-900 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-500">
                <svg className="w-10 h-10 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </div>
              <h3 className="text-2xl font-medium text-white mb-3">Customer</h3>
              <p className="text-zinc-500 font-light">Book appointments, explore styles, and manage your grooming routine.</p>
            </div>
          </div>

          <div 
            onClick={() => setView('shopkeeper_reg')}
            className="group cursor-pointer bg-zinc-950 border border-white/10 p-10 rounded-sm hover:border-amber-500 transition-all text-center relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-amber-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="relative z-10">
              <div className="w-20 h-20 mx-auto bg-zinc-900 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-500">
                <svg className="w-10 h-10 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </div>
              <h3 className="text-2xl font-medium text-white mb-3">Shopkeeper</h3>
              <p className="text-zinc-500 font-light">Manage your barber shop, accept bookings, and grow your business.</p>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
