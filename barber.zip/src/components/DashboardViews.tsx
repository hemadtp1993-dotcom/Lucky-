import React from 'react';
import { ViewState } from '../types';
import { MOCK_BOOKINGS } from '../data';
import { motion } from 'motion/react';
import { Calendar, Clock, CheckCircle, XCircle } from 'lucide-react';

interface DashboardProps {
  setView: (view: ViewState) => void;
}

export const CustomerDashboard: React.FC<DashboardProps> = ({ setView }) => {
  return (
    <div className="min-h-screen bg-black pt-28 pb-20">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-12">
          <div>
            <h2 className="text-3xl font-bold tracking-widest text-white uppercase mb-2">My Dashboard</h2>
            <p className="text-zinc-500 font-light text-lg">Welcome back, John Doe.</p>
          </div>
          <button 
            onClick={() => setView('nearby_shops')}
            className="mt-6 md:mt-0 px-6 py-3 bg-amber-500 text-black font-bold tracking-widest uppercase text-sm rounded-sm hover:bg-amber-400 transition-colors"
          >
            New Booking
          </button>
        </div>

        <div className="space-y-12">
          <section>
            <h3 className="text-xl font-bold tracking-widest text-white uppercase mb-6 border-b border-white/10 pb-4">Current Bookings</h3>
            <div className="space-y-4">
              {MOCK_BOOKINGS.filter(b => b.status === 'pending').map((booking) => (
                <motion.div 
                  key={booking.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-zinc-950 border border-amber-500/30 p-6 rounded-sm flex flex-col md:flex-row md:items-center justify-between"
                >
                  <div className="mb-6 md:mb-0">
                    <div className="flex items-center space-x-3 mb-2">
                      <span className="px-2 py-1 bg-amber-500/10 text-amber-500 text-xs font-bold tracking-wider uppercase rounded-sm">Upcoming</span>
                      <span className="text-zinc-500 font-mono text-sm">{booking.id}</span>
                    </div>
                    <h4 className="text-xl font-bold text-white mb-3">{booking.shopName}</h4>
                    <div className="flex flex-wrap gap-4 text-zinc-400 text-sm">
                      <div className="flex items-center"><Calendar className="w-4 h-4 mr-2 text-amber-500" />{booking.date}</div>
                      <div className="flex items-center"><Clock className="w-4 h-4 mr-2 text-amber-500" />{booking.time}</div>
                    </div>
                    <div className="mt-4 pt-4 border-t border-white/5">
                      <p className="text-zinc-400 text-sm mb-1">Services:</p>
                      <ul className="text-white">
                        {booking.services.map(s => <li key={s.id}>• {s.name}</li>)}
                      </ul>
                    </div>
                  </div>
                  
                  <div className="flex flex-col space-y-3 min-w-[140px]">
                    <button className="w-full py-3 px-4 bg-white text-black text-xs font-bold tracking-widest uppercase rounded-sm hover:bg-zinc-200 transition-colors">
                      Rebook
                    </button>
                    <button className="w-full py-3 px-4 bg-transparent border border-red-500/50 text-red-500 text-xs font-bold tracking-widest uppercase rounded-sm hover:bg-red-500/10 transition-colors">
                      Cancel
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          </section>

          <section>
            <h3 className="text-xl font-bold tracking-widest text-white uppercase mb-6 border-b border-white/10 pb-4">Booking History</h3>
            <div className="space-y-4">
              {MOCK_BOOKINGS.filter(b => b.status === 'completed').map((booking) => (
                <div key={booking.id} className="bg-zinc-950 border border-white/5 p-6 rounded-sm flex flex-col md:flex-row md:items-center justify-between opacity-75">
                  <div className="mb-4 md:mb-0">
                    <div className="flex items-center space-x-3 mb-2">
                      <span className="px-2 py-1 bg-zinc-800 text-zinc-400 text-xs font-bold tracking-wider uppercase rounded-sm">Completed</span>
                      <span className="text-zinc-600 font-mono text-sm">{booking.id}</span>
                    </div>
                    <h4 className="text-lg font-bold text-white mb-2">{booking.shopName}</h4>
                    <p className="text-zinc-500 text-sm">{booking.date} • ₹{booking.totalAmount}</p>
                  </div>
                  <button className="py-2 px-6 bg-zinc-900 border border-white/10 text-white text-xs font-bold tracking-widest uppercase rounded-sm hover:border-amber-500 transition-colors">
                    Rebook
                  </button>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export const ShopkeeperDashboard: React.FC<DashboardProps> = ({ setView }) => {
  return (
    <div className="min-h-screen bg-black pt-28 pb-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-12">
          <div>
            <h2 className="text-3xl font-bold tracking-widest text-white uppercase mb-2">Shop Dashboard</h2>
            <p className="text-amber-500 font-medium text-lg">The Golden Blade</p>
          </div>
          <button className="mt-6 md:mt-0 px-6 py-3 bg-zinc-900 border border-white/10 text-white font-bold tracking-widest uppercase text-sm rounded-sm hover:border-amber-500 transition-colors">
            Manage Profile
          </button>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <section>
              <h3 className="text-xl font-bold tracking-widest text-white uppercase mb-6 border-b border-white/10 pb-4">Recent Bookings</h3>
              <div className="space-y-4">
                {MOCK_BOOKINGS.filter(b => b.status === 'pending').map((booking) => (
                  <motion.div 
                    key={booking.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-zinc-950 border border-white/10 p-6 rounded-sm flex flex-col sm:flex-row sm:items-center justify-between"
                  >
                    <div className="mb-6 sm:mb-0">
                      <div className="flex items-center space-x-3 mb-2">
                        <span className="text-zinc-500 font-mono text-sm">{booking.id}</span>
                      </div>
                      <h4 className="text-xl font-bold text-white mb-2">{booking.customerName}</h4>
                      <div className="flex flex-wrap gap-4 text-zinc-400 text-sm mb-3">
                        <div className="flex items-center"><Calendar className="w-4 h-4 mr-2 text-amber-500" />{booking.date}</div>
                        <div className="flex items-center"><Clock className="w-4 h-4 mr-2 text-amber-500" />{booking.time}</div>
                      </div>
                      <div className="text-sm text-zinc-300 flex flex-wrap gap-x-2 mt-1">
                        <span>{booking.services.map(s => s.name).join(', ')}</span>
                        <span className="text-zinc-600">•</span>
                        <span>Total: <span className="text-white font-bold">₹{booking.totalAmount}</span></span>
                        <span className="text-zinc-600">•</span>
                        <span>Fee (10%): <span className="text-red-400 font-bold">₹{booking.totalAmount * 0.1}</span></span>
                        <span className="text-zinc-600">•</span>
                        <span>Earnings: <span className="text-amber-500 font-bold">₹{booking.totalAmount * 0.9}</span></span>
                      </div>
                    </div>
                    
                    <div className="flex sm:flex-col gap-3">
                      <button className="flex-1 sm:flex-none flex items-center justify-center py-3 px-4 bg-amber-500 text-black text-xs font-bold tracking-widest uppercase rounded-sm hover:bg-amber-400 transition-colors">
                        <CheckCircle className="w-4 h-4 mr-2" /> Accept
                      </button>
                      <button className="flex-1 sm:flex-none flex items-center justify-center py-3 px-4 bg-zinc-900 border border-red-500/30 text-red-500 text-xs font-bold tracking-widest uppercase rounded-sm hover:bg-red-500/10 transition-colors">
                        <XCircle className="w-4 h-4 mr-2" /> Reject
                      </button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </section>

            <section>
              <h3 className="text-xl font-bold tracking-widest text-white uppercase mb-6 border-b border-white/10 pb-4">Today's Schedule</h3>
              <div className="space-y-4">
                 {MOCK_BOOKINGS.filter(b => b.status === 'completed').map((booking) => (
                  <div key={booking.id} className="bg-zinc-950 border border-white/5 p-6 rounded-sm flex items-center justify-between">
                    <div>
                      <div className="text-amber-500 font-bold mb-1">{booking.time}</div>
                      <h4 className="text-white font-medium">{booking.customerName}</h4>
                      <p className="text-zinc-500 text-sm">{booking.services[0].name}</p>
                    </div>
                    <button className="py-2 px-4 bg-zinc-800 text-zinc-400 text-xs font-bold tracking-widest uppercase rounded-sm flex items-center">
                      <CheckCircle className="w-4 h-4 mr-2" /> Marked Completed
                    </button>
                  </div>
                ))}
              </div>
            </section>
          </div>

          <div className="space-y-6">
             <div className="bg-zinc-950 border border-amber-500/20 p-6 rounded-sm">
                <h3 className="text-zinc-400 uppercase tracking-widest text-xs font-bold mb-4 border-b border-white/5 pb-2">Today's Revenue Split</h3>
                
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-zinc-400">Total Booking Value</span>
                  <span className="font-mono text-white">₹24,500</span>
                </div>
                
                <div className="flex justify-between items-center mb-4">
                  <span className="text-sm text-zinc-400">Platform Fee (10%)</span>
                  <span className="font-mono text-red-400">-₹2,450</span>
                </div>
                
                <div className="pt-4 border-t border-white/10">
                  <h3 className="text-zinc-500 uppercase tracking-widest text-xs font-bold mb-1">Your Earnings (90%)</h3>
                  <div className="text-4xl font-bold text-amber-500 mb-1">₹22,050</div>
                  <div className="text-sm text-green-500">+12% from yesterday</div>
                </div>
             </div>
             <div className="bg-zinc-950 border border-white/10 p-6 rounded-sm">
                <h3 className="text-zinc-400 uppercase tracking-widest text-xs font-bold mb-2">Total Bookings</h3>
                <div className="text-4xl font-bold text-white mb-1">12</div>
                <div className="text-sm text-amber-500">4 pending approval</div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};
