import React, { useState } from 'react';
import { ViewState, BarberShop, Service } from '../types';
import { SERVICES } from '../data';
import { motion } from 'motion/react';
import { ArrowLeft, Calendar as CalendarIcon, Clock, Scissors, CheckCircle, User, Phone } from 'lucide-react';

interface BookingFlowProps {
  setView: (view: ViewState) => void;
  selectedShop: BarberShop | null;
  setBookingDetails: (details: any) => void;
  bookingDetails?: any;
}

export const BookingView: React.FC<BookingFlowProps> = ({ setView, selectedShop, setBookingDetails }) => {
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [selectedServices, setSelectedServices] = useState<Service[]>([]);

  React.useEffect(() => {
    if (!selectedShop) {
      setView('nearby_shops');
    }
  }, [selectedShop, setView]);

  if (!selectedShop) {
    return null;
  }

  const toggleService = (service: Service) => {
    if (selectedServices.find(s => s.id === service.id)) {
      setSelectedServices(selectedServices.filter(s => s.id !== service.id));
    } else {
      setSelectedServices([...selectedServices, service]);
    }
  };

  const handleConfirm = () => {
    if (!date || !time || selectedServices.length === 0) return;
    setBookingDetails({
      shop: selectedShop,
      date,
      time,
      services: selectedServices,
      totalAmount: selectedServices.reduce((sum, s) => sum + s.price, 0)
    });
    setView('otp');
  };

  const total = selectedServices.reduce((sum, s) => sum + s.price, 0);

  return (
    <div className="min-h-screen bg-black pt-24 pb-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <button 
          onClick={() => setView('nearby_shops')}
          className="flex items-center text-zinc-500 hover:text-white mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Shops
        </button>

        <div className="mb-10">
          <h2 className="text-3xl font-bold tracking-widest text-white uppercase mb-2">Book Appointment</h2>
          <p className="text-amber-500 font-medium text-lg mb-2">{selectedShop.name}</p>
          <div className="flex flex-col sm:flex-row gap-4 text-sm text-zinc-400">
            {selectedShop.shopkeeperName && (
              <div className="flex items-center">
                <User className="w-4 h-4 mr-2 text-zinc-500" />
                <span>{selectedShop.shopkeeperName}</span>
              </div>
            )}
            {selectedShop.phoneNumber && (
              <div className="flex items-center">
                <Phone className="w-4 h-4 mr-2 text-zinc-500" />
                <span>{selectedShop.phoneNumber}</span>
              </div>
            )}
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          <div className="space-y-8">
            {/* Date Selection */}
            <section>
              <h3 className="flex items-center text-lg font-medium tracking-wide text-white mb-4 uppercase">
                <CalendarIcon className="w-5 h-5 mr-3 text-amber-500" />
                Select Date
              </h3>
              <input 
                type="date" 
                value={date}
                onChange={(e) => setDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
                className="w-full bg-zinc-950 border border-white/10 rounded-sm px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition-colors [color-scheme:dark]"
              />
            </section>

            {/* Time Selection */}
            <section>
              <h3 className="flex items-center text-lg font-medium tracking-wide text-white mb-4 uppercase">
                <Clock className="w-5 h-5 mr-3 text-amber-500" />
                Select Time
              </h3>
              <div className="grid grid-cols-3 gap-3">
                {selectedShop.availableSlots.map(slot => (
                  <button
                    key={slot}
                    onClick={() => setTime(slot)}
                    className={`py-3 text-sm font-medium rounded-sm border transition-colors ${
                      time === slot 
                        ? 'border-amber-500 bg-amber-500/10 text-amber-500' 
                        : 'border-white/10 bg-zinc-950 text-zinc-400 hover:border-white/30'
                    }`}
                  >
                    {slot.replace('Tomorrow ', '')}
                  </button>
                ))}
              </div>
            </section>

            {/* Service Selection */}
            <section>
              <h3 className="flex items-center text-lg font-medium tracking-wide text-white mb-4 uppercase">
                <Scissors className="w-5 h-5 mr-3 text-amber-500" />
                Choose Services
              </h3>
              <div className="space-y-3">
                {SERVICES.map(service => {
                  const isSelected = selectedServices.some(s => s.id === service.id);
                  return (
                    <div 
                      key={service.id}
                      onClick={() => toggleService(service)}
                      className={`flex items-center justify-between p-4 border rounded-sm cursor-pointer transition-colors ${
                        isSelected 
                          ? 'border-amber-500 bg-amber-500/5' 
                          : 'border-white/10 bg-zinc-950 hover:bg-zinc-900'
                      }`}
                    >
                      <div className="flex items-center">
                        <div className={`w-5 h-5 rounded-full border flex items-center justify-center mr-4 ${
                          isSelected ? 'border-amber-500' : 'border-zinc-600'
                        }`}>
                          {isSelected && <div className="w-2.5 h-2.5 bg-amber-500 rounded-full" />}
                        </div>
                        <div>
                          <p className={`font-medium ${isSelected ? 'text-white' : 'text-zinc-300'}`}>{service.name}</p>
                          <p className="text-xs text-zinc-500">{service.duration} mins</p>
                        </div>
                      </div>
                      <span className="font-bold text-white">₹{service.price}</span>
                    </div>
                  );
                })}
              </div>
            </section>
          </div>

          {/* Summary Panel */}
          <div>
            <div className="bg-zinc-950 border border-white/10 p-6 rounded-sm sticky top-28">
              <h3 className="text-xl font-bold tracking-widest text-white uppercase mb-6 border-b border-white/10 pb-4">Booking Summary</h3>
              
              <div className="space-y-4 mb-8">
                <div className="flex justify-between text-sm">
                  <span className="text-zinc-500">Date</span>
                  <span className="text-white font-medium">{date || 'Not selected'}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-zinc-500">Time</span>
                  <span className="text-white font-medium">{time || 'Not selected'}</span>
                </div>
                
                <div className="border-t border-white/10 pt-4 mt-4">
                  <span className="text-zinc-500 text-sm block mb-3">Selected Services</span>
                  {selectedServices.length > 0 ? (
                    <div className="space-y-2">
                      {selectedServices.map(s => (
                        <div key={s.id} className="flex justify-between text-sm">
                          <span className="text-zinc-300">{s.name}</span>
                          <span className="text-white">₹{s.price}</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <span className="text-zinc-600 text-sm italic">No services selected</span>
                  )}
                </div>
              </div>

              <div className="border-t border-white/10 pt-6 mb-8 flex justify-between items-center">
                <span className="text-lg font-bold text-white uppercase tracking-wider">Total</span>
                <span className="text-3xl font-bold text-amber-500">₹{total}</span>
              </div>

              <button
                onClick={handleConfirm}
                disabled={!date || !time || selectedServices.length === 0}
                className="w-full py-4 text-sm font-bold tracking-widest uppercase rounded-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed bg-amber-500 text-black hover:bg-amber-400"
              >
                Confirm Booking
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export const OtpView: React.FC<BookingFlowProps> = ({ setView }) => {
  const [otp, setOtp] = useState(['', '', '', '']);

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.join('').length === 4) {
      setView('success');
    } else {
      alert('Please enter a 4-digit OTP');
    }
  };

  const handleChange = (index: number, value: string) => {
    if (value.length > 1) value = value.slice(0, 1);
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    
    // Auto focus next
    if (value && index < 3) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      if (nextInput) nextInput.focus();
    }
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md w-full bg-zinc-950 border border-white/10 p-10 rounded-sm shadow-2xl text-center"
      >
        <h2 className="text-3xl font-bold tracking-widest text-white uppercase mb-2">Verification</h2>
        <p className="text-zinc-500 font-light mb-8">Enter the 4-digit code sent to your phone</p>

        <form onSubmit={handleVerify}>
          <div className="flex justify-center gap-4 mb-10">
            {otp.map((digit, index) => (
              <input
                key={index}
                id={`otp-${index}`}
                type="text"
                maxLength={1}
                value={digit}
                onChange={(e) => handleChange(index, e.target.value)}
                className="w-14 h-16 text-center text-2xl font-bold text-white bg-zinc-900 border border-white/20 rounded-sm focus:outline-none focus:border-amber-500 transition-colors"
              />
            ))}
          </div>

          <button 
            type="submit"
            className="w-full flex items-center justify-center px-4 py-4 bg-amber-500 text-black rounded-sm hover:bg-amber-400 transition-colors font-bold tracking-widest uppercase text-sm mb-6"
          >
            Verify & Confirm
          </button>

          <button type="button" className="text-zinc-500 hover:text-white text-sm transition-colors">
            Didn't receive the code? <span className="text-amber-500">Resend OTP</span>
          </button>
        </form>
      </motion.div>
    </div>
  );
};

export const SuccessView: React.FC<BookingFlowProps> = ({ setView, bookingDetails }) => {
  React.useEffect(() => {
    if (!bookingDetails) {
      setView('home');
    }
  }, [bookingDetails, setView]);

  if (!bookingDetails) {
    return null;
  }

  return (
    <div className="min-h-screen bg-black pt-28 pb-20 flex flex-col items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-white text-black p-8 rounded-sm shadow-2xl relative overflow-hidden"
      >
        <div className="absolute top-0 left-0 w-full h-2 bg-amber-500" />
        
        <div className="text-center mb-8">
          <CheckCircle className="w-16 h-16 text-amber-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold uppercase tracking-widest">Booking Confirmed</h2>
          <p className="text-zinc-500 mt-2 text-sm">Your appointment has been successfully scheduled.</p>
        </div>

        <div className="bg-zinc-50 p-6 rounded-sm mb-8 border border-zinc-200">
          <div className="space-y-4">
            <div className="flex justify-between border-b border-zinc-200 pb-3">
              <span className="text-zinc-500 text-sm">Booking ID</span>
              <span className="font-bold font-mono">BKG-{Math.floor(10000 + Math.random() * 90000)}</span>
            </div>
            <div className="flex justify-between border-b border-zinc-200 pb-3">
              <span className="text-zinc-500 text-sm">Customer</span>
              <span className="font-bold">John Doe</span>
            </div>
            <div className="flex justify-between border-b border-zinc-200 pb-3">
              <span className="text-zinc-500 text-sm">Shop</span>
              <span className="font-bold text-right">{bookingDetails.shop.name}</span>
            </div>
            {(bookingDetails.shop.shopkeeperName || bookingDetails.shop.phoneNumber) && (
              <div className="flex justify-between border-b border-zinc-200 pb-3">
                <span className="text-zinc-500 text-sm">Contact</span>
                <div className="text-right">
                  {bookingDetails.shop.shopkeeperName && <div className="font-bold">{bookingDetails.shop.shopkeeperName}</div>}
                  {bookingDetails.shop.phoneNumber && <div className="text-sm text-zinc-600">{bookingDetails.shop.phoneNumber}</div>}
                </div>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-zinc-500 text-sm">Date & Time</span>
              <span className="font-bold text-right text-amber-600">{bookingDetails.date} at {bookingDetails.time}</span>
            </div>
          </div>
        </div>

        <div className="text-center mb-8">
          <div className="inline-block p-4 bg-white border-2 border-black rounded-sm mb-2">
            <svg className="w-32 h-32" viewBox="0 0 24 24" fill="currentColor">
              <path d="M3 3h8v8H3zm2 2v4h4V5zm8-2h8v8h-8zm2 2v4h4V5zM3 13h8v8H3zm2 2v4h4v-4zm13-2h2v2h-2zm-3 3h2v2h-2zm3 3h2v2h-2zm-3-6h2v2h-2zm-3 3h2v2h-2zm0 3h2v2h-2zm-3-3h2v2h-2zm0-3h2v2h-2z" />
            </svg>
          </div>
          <p className="text-xs text-zinc-500 uppercase tracking-widest">Show this QR at the shop</p>
        </div>

        <div className="space-y-3">
          <button className="w-full py-4 text-sm font-bold tracking-widest uppercase bg-black text-white rounded-sm hover:bg-zinc-900 transition-colors">
            Download Receipt
          </button>
          <button 
            onClick={() => setView('customer_dashboard')}
            className="w-full py-4 text-sm font-bold tracking-widest uppercase bg-transparent text-black border border-black rounded-sm hover:bg-zinc-100 transition-colors"
          >
            Go to Dashboard
          </button>
        </div>
      </motion.div>
    </div>
  );
};
