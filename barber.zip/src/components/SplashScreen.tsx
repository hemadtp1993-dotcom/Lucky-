import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Scissors } from 'lucide-react';

interface SplashScreenProps {
  isVisible: boolean;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ isVisible }) => {
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, y: -50 }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center overflow-hidden"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 1.1, opacity: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="flex flex-col items-center"
          >
            {/* Animated Scissors Icon */}
            <motion.div
              initial={{ rotate: -45, x: -20, opacity: 0 }}
              animate={{ rotate: 0, x: 0, opacity: 1 }}
              transition={{ duration: 0.8, type: "spring", bounce: 0.4 }}
              className="relative"
            >
              <motion.div
                animate={{ rotate: [0, -15, 10, -15, 0] }}
                transition={{ duration: 1.5, ease: "easeInOut", delay: 0.5 }}
              >
                <Scissors className="w-24 h-24 text-amber-500 mb-6" strokeWidth={1.5} />
              </motion.div>
            </motion.div>

            {/* Typography */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="flex items-center gap-2 overflow-hidden"
            >
              <h1 className="text-4xl md:text-5xl font-bold tracking-[0.2em] text-white uppercase">
                Groom<span className="text-amber-500 italic font-serif lowercase px-1 text-5xl md:text-6xl">ing</span>
              </h1>
            </motion.div>

            {/* Subtitle Line */}
            <motion.div
              initial={{ scaleX: 0, opacity: 0 }}
              animate={{ scaleX: 1, opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.8, ease: "easeOut" }}
              className="w-32 h-1 bg-gradient-to-r from-amber-500/0 via-amber-500 to-amber-500/0 mt-8 rounded-full"
            />
            
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 1 }}
              className="mt-4 text-zinc-500 tracking-widest text-xs uppercase"
            >
              Premium Salon & Beauty
            </motion.p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
