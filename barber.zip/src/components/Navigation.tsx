import React from 'react';
import { ViewState } from '../types';
import { Scissors, Menu, X, User as UserIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface NavigationProps {
  currentView: ViewState;
  setView: (view: ViewState) => void;
  isLoggedIn: boolean;
  logout: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({ currentView, setView, isLoggedIn, logout }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  const navLinks = [
    { name: 'Home', view: 'home' as ViewState },
    { name: 'Nearby Shops', view: 'nearby_shops' as ViewState },
    { name: 'Services', view: 'home' as ViewState },
    { name: 'Contact', view: 'home' as ViewState },
  ];

  const handleNavClick = (view: ViewState) => {
    setView(view);
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className="fixed w-full z-50 bg-black/90 backdrop-blur-md border-b border-amber-900/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20">
          <div className="flex items-center cursor-pointer" onClick={() => handleNavClick('home')}>
            <Scissors className="h-8 w-8 text-amber-500" />
            <span className="ml-2 text-2xl font-bold tracking-widest text-white uppercase">Barber<span className="text-amber-500">.</span></span>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <button
                key={link.name}
                onClick={() => handleNavClick(link.view)}
                className={`text-sm font-medium tracking-wide uppercase transition-colors hover:text-amber-500 ${
                  currentView === link.view && link.view !== 'home' ? 'text-amber-500' : 'text-zinc-400'
                }`}
              >
                {link.name}
              </button>
            ))}
            
            {isLoggedIn ? (
              <div className="flex items-center space-x-4">
                <button 
                  onClick={() => handleNavClick('customer_dashboard')}
                  className="p-2 text-zinc-400 hover:text-amber-500 transition-colors"
                >
                  <UserIcon className="w-5 h-5" />
                </button>
                <button 
                  onClick={logout}
                  className="px-5 py-2 text-sm font-medium tracking-wide text-black uppercase bg-amber-500 rounded hover:bg-amber-400 transition-colors"
                >
                  Logout
                </button>
              </div>
            ) : (
              <button 
                onClick={() => handleNavClick('login')}
                className="px-5 py-2 text-sm font-medium tracking-wide text-black uppercase bg-amber-500 rounded hover:bg-amber-400 transition-colors"
              >
                Login
              </button>
            )}
          </div>

          <div className="flex items-center md:hidden">
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-zinc-400 hover:text-amber-500"
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-zinc-950 border-b border-amber-900/30 overflow-hidden"
          >
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              {navLinks.map((link) => (
                <button
                  key={link.name}
                  onClick={() => handleNavClick(link.view)}
                  className="block w-full text-left px-3 py-4 text-base font-medium tracking-wide text-zinc-400 uppercase hover:text-amber-500 hover:bg-zinc-900 rounded-md"
                >
                  {link.name}
                </button>
              ))}
              {isLoggedIn ? (
                <>
                  <button
                    onClick={() => handleNavClick('customer_dashboard')}
                    className="block w-full text-left px-3 py-4 text-base font-medium tracking-wide text-amber-500 uppercase hover:bg-zinc-900 rounded-md"
                  >
                    Dashboard
                  </button>
                  <button
                    onClick={() => { logout(); setIsMobileMenuOpen(false); }}
                    className="block w-full text-left px-3 py-4 text-base font-medium tracking-wide text-zinc-400 uppercase hover:bg-zinc-900 rounded-md"
                  >
                    Logout
                  </button>
                </>
              ) : (
                <button
                  onClick={() => handleNavClick('login')}
                  className="block w-full text-left px-3 py-4 text-base font-medium tracking-wide text-amber-500 uppercase hover:bg-zinc-900 rounded-md"
                >
                  Login
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};
