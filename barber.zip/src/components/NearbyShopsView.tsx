import React from 'react';
import { ViewState, BarberShop, LocationCoords } from '../types';
import { MOCK_SHOPS } from '../data';
import { motion } from 'motion/react';
import { MapPin, Star, Clock, Navigation, Phone, User } from 'lucide-react';

interface NearbyShopsViewProps {
  setView: (view: ViewState) => void;
  setSelectedShop: (shop: BarberShop) => void;
  userLocation: LocationCoords | null;
  setUserLocation: (location: LocationCoords | null) => void;
  genderPreference: 'male' | 'female' | 'all';
}

export const NearbyShopsView: React.FC<NearbyShopsViewProps> = ({ setView, setSelectedShop, userLocation, setUserLocation, genderPreference }) => {
  const [locationError, setLocationError] = React.useState<string | null>(null);

  React.useEffect(() => {
    if (!userLocation && 'geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({ lat: position.coords.latitude, lng: position.coords.longitude });
          setLocationError(null);
        },
        (error) => {
          console.log('Location access denied:', error.message);
          setLocationError('Location access denied. Displaying default shops.');
        }
      );
    }
  }, [userLocation, setUserLocation]);

  const handleBook = (shop: BarberShop) => {
    setSelectedShop(shop);
    setView('booking');
  };

  const filteredShops = MOCK_SHOPS.filter(shop => {
    if (genderPreference === 'all') return true;
    return shop.targetGender === genderPreference || shop.targetGender === 'unisex';
  });

  return (
    <div className="min-h-screen bg-black pt-28 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-12">
          <h2 className="text-3xl md:text-4xl font-bold tracking-widest text-white uppercase mb-4">
            {genderPreference === 'male' ? 'Nearby Saloons' : genderPreference === 'female' ? 'Nearby Beauty Parlors' : 'Nearby Shops'}
          </h2>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <p className="text-zinc-500 font-light text-lg">Discover and book the finest grooming experiences around you.</p>
            {userLocation ? (
              <div className="flex items-center text-amber-500 bg-amber-500/10 px-4 py-2 rounded-sm w-fit">
                <Navigation className="w-4 h-4 mr-2" />
                <span className="text-sm font-medium">Using live location</span>
              </div>
            ) : locationError ? (
              <div className="flex items-center text-red-500 bg-red-500/10 px-4 py-2 rounded-sm w-fit">
                <span className="text-sm font-medium">{locationError}</span>
              </div>
            ) : (
               <div className="flex items-center text-zinc-400 bg-zinc-900 px-4 py-2 rounded-sm w-fit">
                <span className="text-sm font-medium animate-pulse">Requesting location...</span>
              </div>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredShops.map((shop, index) => (
            <motion.div
              key={shop.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-zinc-950 border border-white/5 rounded-sm overflow-hidden group hover:border-amber-500/50 transition-colors"
            >
              <div className="relative h-64 overflow-hidden">
                <img 
                  src={shop.image} 
                  alt={shop.name} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                
                <div className="absolute top-4 right-4 flex items-center space-x-2">
                  <div className={`px-3 py-1 rounded-sm text-xs font-bold tracking-widest uppercase ${shop.isOpen ? 'bg-amber-500 text-black' : 'bg-red-500 text-white'}`}>
                    {shop.isOpen ? 'Open' : 'Closed'}
                  </div>
                </div>

                <div className="absolute bottom-4 left-4 right-4">
                  <h3 className="text-2xl font-bold text-white mb-2">{shop.name}</h3>
                  <div className="flex items-center text-amber-500 mb-1">
                    <Star className="w-4 h-4 fill-current" />
                    <span className="ml-1 text-sm font-medium text-white">{shop.rating}</span>
                  </div>
                </div>
              </div>

              <div className="p-6">
                <div className="space-y-3 mb-6">
                  {shop.shopkeeperName && (
                    <div className="flex items-start text-zinc-400">
                      <User className="w-5 h-5 mr-3 shrink-0" />
                      <span className="text-sm">{shop.shopkeeperName}</span>
                    </div>
                  )}
                  {shop.phoneNumber && (
                    <div className="flex items-start text-zinc-400">
                      <Phone className="w-5 h-5 mr-3 shrink-0" />
                      <span className="text-sm">{shop.phoneNumber}</span>
                    </div>
                  )}
                  <div className="flex items-start text-zinc-400">
                    <MapPin className="w-5 h-5 mr-3 shrink-0" />
                    <span className="text-sm">{shop.address} <span className="text-zinc-600 block mt-1">{shop.distance} away</span></span>
                  </div>
                  <div className="flex items-start text-zinc-400">
                    <Clock className="w-5 h-5 mr-3 shrink-0" />
                    <div className="text-sm">
                      <p className="mb-2">Available Slots:</p>
                      <div className="flex flex-wrap gap-2">
                        {shop.availableSlots.map((slot, i) => (
                          <span key={i} className="px-2 py-1 bg-zinc-900 text-zinc-300 rounded text-xs">
                            {slot}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => handleBook(shop)}
                  disabled={!shop.isOpen}
                  className={`w-full py-3 text-sm font-bold tracking-widest uppercase rounded-sm transition-colors ${
                    shop.isOpen 
                      ? 'bg-white text-black hover:bg-amber-500' 
                      : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                  }`}
                >
                  {shop.isOpen ? 'Book Now' : 'Currently Closed'}
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};
