import React, { useState, useEffect } from 'react';
import { ViewState, User, BarberShop, LocationCoords } from './types';
import { Navigation } from './components/Navigation';
import { HomeView } from './components/HomeView';
import { LoginView, RoleSelectView, EmailLoginView } from './components/AuthViews';
import { CustomerRegView, ShopkeeperRegView } from './components/RegViews';
import { NearbyShopsView } from './components/NearbyShopsView';
import { BookingView, OtpView, SuccessView } from './components/BookingFlowViews';
import { CustomerDashboard, ShopkeeperDashboard } from './components/DashboardViews';
import { SplashScreen } from './components/SplashScreen';
import { auth, signOut as firebaseSignOut } from './lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [currentView, setCurrentView] = useState<ViewState>('home');
  const [user, setUser] = useState<User | null>(null);
  const [selectedShop, setSelectedShop] = useState<BarberShop | null>(null);
  const [bookingDetails, setBookingDetails] = useState<any>(null);
  const [userLocation, setUserLocation] = useState<LocationCoords | null>(null);
  const [genderPreference, setGenderPreference] = useState<'male' | 'female' | 'all'>('all');

  useEffect(() => {
    // Hide splash screen after 2.5 seconds
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2500);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      if (firebaseUser) {
        // Since we don't have a backend to store roles yet, we'll store role in localStorage or assume customer if unknown
        const role = localStorage.getItem('user_role') || 'customer';
        setUser({ 
          id: firebaseUser.uid, 
          name: firebaseUser.displayName || 'User', 
          email: firebaseUser.email || '', 
          role: role as 'customer' | 'shopkeeper'
        });
        setCurrentView(role === 'shopkeeper' ? 'shopkeeper_dashboard' : 'customer_dashboard');
      } else {
        setUser(null);
      }
    });
    return () => unsubscribe();
  }, []);

  const logout = async () => {
    try {
      await firebaseSignOut();
      setUser(null);
      setCurrentView('home');
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  const renderView = () => {
    switch (currentView) {
      case 'home':
        return <HomeView setView={setCurrentView} setGenderPreference={setGenderPreference} />;
      case 'login':
        return <LoginView setView={setCurrentView} setUser={setUser} />;
      case 'email_login':
        return <EmailLoginView setView={setCurrentView} setUser={setUser} />;
      case 'role_select':
        return <RoleSelectView setView={setCurrentView} setUser={setUser} />;
      case 'customer_reg':
        return <CustomerRegView setView={setCurrentView} setUser={setUser} />;
      case 'shopkeeper_reg':
        return <ShopkeeperRegView setView={setCurrentView} setUser={setUser} />;
      case 'nearby_shops':
        return <NearbyShopsView setView={setCurrentView} setSelectedShop={setSelectedShop} userLocation={userLocation} setUserLocation={setUserLocation} genderPreference={genderPreference} />;
      case 'booking':
        return <BookingView setView={setCurrentView} selectedShop={selectedShop} setBookingDetails={setBookingDetails} />;
      case 'otp':
        return <OtpView setView={setCurrentView} selectedShop={selectedShop} setBookingDetails={setBookingDetails} />;
      case 'success':
        return <SuccessView setView={setCurrentView} selectedShop={selectedShop} setBookingDetails={setBookingDetails} />;
      case 'customer_dashboard':
        return <CustomerDashboard setView={setCurrentView} />;
      case 'shopkeeper_dashboard':
        return <ShopkeeperDashboard setView={setCurrentView} />;
      default:
        return <HomeView setView={setCurrentView} />;
    }
  };

  return (
    <div className="font-sans text-white bg-black min-h-screen selection:bg-amber-500/30 selection:text-amber-500">
      <SplashScreen isVisible={showSplash} />
      <Navigation 
        currentView={currentView} 
        setView={setCurrentView} 
        isLoggedIn={!!user} 
        logout={logout} 
      />
      <main>
        {renderView()}
      </main>
    </div>
  );
}
