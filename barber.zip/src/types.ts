export type ViewState = 
  | 'home' 
  | 'login' 
  | 'email_login'
  | 'role_select' 
  | 'customer_reg' 
  | 'shopkeeper_reg' 
  | 'nearby_shops' 
  | 'booking' 
  | 'otp' 
  | 'success' 
  | 'shopkeeper_dashboard' 
  | 'customer_dashboard';

export interface LocationCoords {
  lat: number;
  lng: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'customer' | 'shopkeeper';
}

export interface BarberShop {
  id: string;
  name: string;
  address: string;
  distance: string;
  rating: number;
  isOpen: boolean;
  image: string;
  availableSlots: string[];
  targetGender?: 'male' | 'female' | 'unisex';
  shopkeeperName?: string;
  phoneNumber?: string;
}

export interface Service {
  id: string;
  name: string;
  price: number;
  duration: number; // in minutes
}

export interface Booking {
  id: string;
  shopId: string;
  shopName: string;
  customerId: string;
  customerName: string;
  date: string;
  time: string;
  services: Service[];
  totalAmount: number;
  status: 'pending' | 'accepted' | 'rejected' | 'completed' | 'cancelled';
}
