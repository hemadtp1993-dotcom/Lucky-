import { BarberShop, Service, Booking } from './types';

export const MOCK_SHOPS: BarberShop[] = [
  {
    id: '1',
    name: 'The Golden Blade',
    address: '123 Elite Avenue, Downtown',
    distance: '0.8 km',
    rating: 4.9,
    isOpen: true,
    image: 'https://images.unsplash.com/photo-1585747860715-2ba37e788b70?auto=format&fit=crop&q=80&w=800',
    availableSlots: ['10:00 AM', '11:30 AM', '02:00 PM', '04:00 PM'],
    targetGender: 'male',
    shopkeeperName: 'Marcus Johnson',
    phoneNumber: '+91 98765 43210'
  },
  {
    id: '2',
    name: 'Vintage Scissors',
    address: '45 Heritage Street, Westside',
    distance: '1.2 km',
    rating: 4.7,
    isOpen: true,
    image: 'https://images.unsplash.com/photo-1599351431202-1e0f0137899a?auto=format&fit=crop&q=80&w=800',
    availableSlots: ['09:00 AM', '01:00 PM', '03:30 PM', '05:00 PM'],
    targetGender: 'male',
    shopkeeperName: 'David Smith',
    phoneNumber: '+91 87654 32109'
  },
  {
    id: '3',
    name: 'Kingsman Grooming',
    address: '88 Royal Boulevard',
    distance: '2.5 km',
    rating: 4.8,
    isOpen: false,
    image: 'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&q=80&w=800',
    availableSlots: ['Tomorrow 10:00 AM', 'Tomorrow 12:00 PM'],
    targetGender: 'male',
    shopkeeperName: 'Rahul Verma',
    phoneNumber: '+91 76543 21098'
  },
  {
    id: '4',
    name: 'Elegance Beauty Parlor',
    address: '12 Rosewood Lane',
    distance: '1.0 km',
    rating: 4.9,
    isOpen: true,
    image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&q=80&w=800',
    availableSlots: ['11:00 AM', '01:00 PM', '04:00 PM'],
    targetGender: 'female',
    shopkeeperName: 'Priya Sharma',
    phoneNumber: '+91 65432 10987'
  },
  {
    id: '5',
    name: 'Glow Up Salon',
    address: '55 Blossom Avenue',
    distance: '1.8 km',
    rating: 4.8,
    isOpen: true,
    image: 'https://images.unsplash.com/photo-1522337660859-02fbefca4702?auto=format&fit=crop&q=80&w=800',
    availableSlots: ['09:30 AM', '02:30 PM', '05:00 PM'],
    targetGender: 'female',
    shopkeeperName: 'Anita Desai',
    phoneNumber: '+91 54321 09876'
  }
];

export const SERVICES: Service[] = [
  { id: 's1', name: 'Premium Haircut', price: 350, duration: 45 },
  { id: 's2', name: 'Beard Trim & Shape', price: 200, duration: 30 },
  { id: 's3', name: 'Hair Styling', price: 250, duration: 30 },
  { id: 's4', name: 'Refreshing Hair Wash', price: 150, duration: 15 },
  { id: 's5', name: 'Hot Towel Shave', price: 300, duration: 40 },
];

export const MOCK_BOOKINGS: Booking[] = [
  {
    id: 'BKG-88392',
    shopId: '1',
    shopName: 'The Golden Blade',
    customerId: 'c1',
    customerName: 'John Doe',
    date: '2023-11-15',
    time: '10:00 AM',
    services: [SERVICES[0], SERVICES[1]],
    totalAmount: 550,
    status: 'completed'
  },
  {
    id: 'BKG-99201',
    shopId: '1',
    shopName: 'The Golden Blade',
    customerId: 'c1',
    customerName: 'John Doe',
    date: '2024-02-20',
    time: '02:00 PM',
    services: [SERVICES[0]],
    totalAmount: 350,
    status: 'pending'
  }
];
